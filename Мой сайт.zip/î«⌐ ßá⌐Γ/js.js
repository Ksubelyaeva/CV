var button = document.querySelector('button');

button.addEventListener('click', function() {
	console.log('log:Выведи этот текст в консоль, если кнопка нажмется');
	alert('Хорошего настроения!')
})